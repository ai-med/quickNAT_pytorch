# quickNAT_pytorch

PyTorch Implementation of QuickNAT

Under Developement
