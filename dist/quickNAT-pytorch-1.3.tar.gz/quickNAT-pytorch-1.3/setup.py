import setuptools

setuptools.setup(name="quickNAT-pytorch",
    version="1.3",
    url="https://github.com/abhi4ssj/quickNAT_pytorch",
    author="Abhijit Guha Roy",
    author_email="abhi4ssj@gmail.com",
    description="QuickNAT, Brain segmentation.",
    packages=setuptools.find_packages(),
    install_requires=[])
